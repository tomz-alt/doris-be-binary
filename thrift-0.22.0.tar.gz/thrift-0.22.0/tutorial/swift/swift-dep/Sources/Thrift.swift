class Thrift {
	let version = "0.22.0"
}
