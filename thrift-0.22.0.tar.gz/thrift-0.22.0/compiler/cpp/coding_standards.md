## Compiler Coding Standards

 * When making small change / bugfix - follow style as seen in nearby code.
 * When making major refactor and / or adding new feature - follow style for C++ library